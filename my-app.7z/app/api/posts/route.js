/** @format */

import { NextResponse } from "next/server";

// CORRECTED: This function now reads URL parameters for pagination
export async function GET(request) {
    try {
        // Get the search parameters from the incoming request's URL
        const { searchParams } = new URL(request.url);
        const page = searchParams.get("page") || "1";
        const limit = searchParams.get("limit") || "10";

        // Construct the correct URL to fetch from the external API
        const apiUrl = `${process.env.API_URL}/posts?page=${page}&limit=${limit}`;

        const res = await fetch(apiUrl);
        const data = await res.json();
        return NextResponse.json(data, { status: res.status });
    } catch (error) {
        return NextResponse.json(
            { message: "An unexpected error occurred." },
            { status: 500 }
        );
    }
}

export async function POST(req) {
    try {
        const formData = await req.formData();
        // Proxy the formData directly to the external API
        const res = await fetch(`${process.env.API_URL}/posts`, {
            method: "POST",
            body: formData,
            headers: {
                Accept: "application/json",
                Authorization: formData.get("token")
                    ? `Bearer ${formData.get("token")}`
                    : undefined,
            },
        });
        const data = await res.json();
        return NextResponse.json(data, { status: res.status });
    } catch (error) {
        return NextResponse.json(
            { message: "An unexpected error occurred." },
            { status: 500 }
        );
    }
}
