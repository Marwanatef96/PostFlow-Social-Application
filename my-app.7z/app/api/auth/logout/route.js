/** @format */

import { NextResponse } from "next/server";

export const dynamic = 'force-dynamic';

export async function POST() {
    const res = await fetch("https://tarmeezacademy.com/api/v1/logout", {
        method: "POST",
    });
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
}
