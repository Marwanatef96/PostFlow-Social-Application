/** @format */

import { NextResponse } from "next/server";

// Best practice: Define constants for external URLs
const EXTERNAL_API_URL = `${process.env.API_URL}/register`;

export const config = {
    api: { bodyParser: false },
};

/**
 * Handles user registration by forwarding the request to an external API.
 * It expects multipart/form-data, remaps the 'avatar' field to 'image',
 * and proxies the data.
 * @param {Request} req - The incoming request object.
 * @returns {NextResponse} - The response from the external API or an error response.
 */
export const POST = async (req) => {
    try {
        const formData = await req.formData();

        // The external API expects the image field to be named 'image'.
        // The client sends it as 'avatar'. We remap it here.
        const avatarFile = formData.get("avatar");
        if (avatarFile) {
            formData.append("image", avatarFile);
            formData.delete("avatar");
        }

        const res = await fetch(EXTERNAL_API_URL, {
            method: "POST",
            body: formData,
            headers: {
                Accept: "application/json",
            },
        });

        // The external API might return a non-JSON error response.
        if (!res.ok) {
            const errorText = await res.text();
            // Log the detailed error for debugging on the server.
            console.error(`External API Error (${res.status}):`, errorText);
            // Return a generic error to the client.
            return NextResponse.json(
                {
                    message:
                        "Registration failed due to an external service error.",
                },
                { status: res.status }
            );
        }

        const data = await res.json();
        return NextResponse.json(data, { status: res.status });
    } catch (err) {
        // This catches errors from req.formData(), fetch(), or res.json()
        console.error("Registration route internal error:", err);

        // Check if the error is due to a non-JSON response from the external API
        if (err instanceof SyntaxError) {
            return NextResponse.json(
                {
                    message:
                        "Received an invalid response from the registration service.",
                },
                { status: 502 } // Bad Gateway
            );
        }

        return NextResponse.json(
            { message: "An unexpected server error occurred." },
            { status: 500 }
        );
    }
};

