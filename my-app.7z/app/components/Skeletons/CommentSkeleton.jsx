/** @format */

import * as React from "react";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Skeleton from "@mui/material/Skeleton";
import ListItem from "@mui/material/ListItem";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import Avatar from "@mui/material/Avatar";
import ListItemText from "@mui/material/ListItemText";

export default function CommentSkeleton() {
    return (
        <ListItem alignItems='flex-start'>
            <ListItemAvatar>
                <Skeleton variant='circular'>
                    <Avatar />
                </Skeleton>
            </ListItemAvatar>
            <ListItemText
                primary={<Skeleton width={120} height={18} />}
                secondary={<Skeleton width={220} height={14} />}
            />
        </ListItem>
    );
}
