/** @format */

import * as React from "react";
// import removed: lightTheme from "../../../lib/theme";
import { useThemeMode } from "../../../lib/ThemeContext";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Skeleton from "@mui/material/Skeleton";
import Stack from "@mui/material/Stack";

export default function ProfileSkeleton() {
    const { theme } = useThemeMode();
    return (
        <Box
            sx={{
                width: 300,
                margin: "auto",
                mt: 4,
                background: "var(--color-surface)",
                borderRadius: "var(--border-radius)",
                boxShadow: "0 2px 8px rgba(60,60,60,0.06)",
                p: theme.spacing(3),
            }}>
            <Skeleton
                variant='circular'
                width={80}
                height={80}
                sx={{ margin: "auto", mb: theme.spacing(2) }}
            />
            <Skeleton
                height={30}
                width='60%'
                sx={{ margin: `${theme.spacing(2)} auto` }}
            />
            <Skeleton
                height={20}
                width='80%'
                sx={{ margin: `${theme.spacing(1)} auto` }}
            />
            <Skeleton
                height={20}
                width='80%'
                sx={{ margin: `${theme.spacing(1)} auto` }}
            />
        </Box>
    );
}
