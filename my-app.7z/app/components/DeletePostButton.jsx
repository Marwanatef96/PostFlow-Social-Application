/** @format */

import React, { useState } from "react";
import { useDeletePost, useInfinitePosts } from "../lib/hooks/usePosts";
import DeletePostConfirmModal from "./DeletePostConfirmModal";
import Button from "@mui/material/Button";
import ModernTooltip, { useTooltipState } from "./ModernTooltip/ModernTooltip";

export default function DeletePostButton({ postId, mutatePosts }) {
    const [open, setOpen] = useState(false);
    const { deletePost, isDeleting } = useDeletePost();
    const tooltip = useTooltipState(false);
    const [tooltipContent, setTooltipContent] = useState("");
    const [tooltipVariant, setTooltipVariant] = useState("success");

    const handleDelete = async () => {
        try {
            await deletePost({ postId });
            setOpen(false);
            if (mutatePosts) {
                setTimeout(() => mutatePosts(), 200);
            }
            setTooltipVariant("success");
            setTooltipContent("Post deleted successfully");
            tooltip.onOpen();
        } catch (err) {
            setTooltipVariant("error");
            setTooltipContent(
                err.info?.message ||
                    `Delete failed (${err.status || "unknown"})`
            );
            tooltip.onOpen();
        }
    };

    return (
        <>
            <ModernTooltip
                title={tooltipContent}
                variant={tooltipVariant}
                open={tooltip.open}
                onClose={tooltip.onClose}>
                <Button
                    onClick={() => setOpen(true)}
                    color='error'
                    variant='text'
                    sx={{ ml: 1 }}>
                    Delete
                </Button>
            </ModernTooltip>
            <DeletePostConfirmModal
                open={open}
                onClose={() => setOpen(false)}
                onConfirm={handleDelete}
                loading={isDeleting}
            />
        </>
    );
}
