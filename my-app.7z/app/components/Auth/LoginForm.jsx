/** @format */

"use client";

import * as React from "react";
import { useAuth } from "../../lib/hooks/useAuth";
import { Box, Button, TextField, Typography } from "@mui/material";

export default function LoginForm() {
    const { login, isLoggingIn } = useAuth();
    const [username, setUsername] = React.useState("");
    const [password, setPassword] = React.useState("");

    const handleLogin = async () => {
        try {
            await login({ username, password });
        } catch (err) {
            console.error("Login error:", err);
        }
    };

    return (
        <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
            <TextField
                size='small'
                label='Username'
                value={username}
                onChange={(e) => setUsername(e.target.value)}
            />
            <TextField
                size='small'
                type='password'
                label='Password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <Button
                variant='outlined'
                color='inherit'
                onClick={handleLogin}
                disabled={isLoggingIn}>
                {isLoggingIn ? "Logging in..." : "Login"}
            </Button>
        </Box>
    );
}
