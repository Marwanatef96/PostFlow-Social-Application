/** @format */

"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { useAuth } from "../../lib/hooks/useAuth";
import {
    Button,
    TextField,
    Typography,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    CircularProgress,
} from "@mui/material";
import ModernTooltip, {
    useTooltipState,
    ErrorTooltip,
    SuccessTooltip,
} from "../ModernTooltip/ModernTooltip";

export default function LoginModal({ buttonText = "Login" }) {
    const { login, isLoggingIn } = useAuth();
    const [open, setOpen] = React.useState(false);
    const [error, setError] = React.useState(null);
    const tooltip = useTooltipState(false);
    const [tooltipContent, setTooltipContent] = React.useState("");
    const [tooltipVariant, setTooltipVariant] = React.useState("success");
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
    } = useForm({
        defaultValues: {
            username: "zxczxc",
            password: "zxczxc",
        },
    });

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        setError(null);
        reset();
    };

    const onSubmit = async (data) => {
        setError(null);
        try {
            await login({ username: data.username, password: data.password });
            setTooltipVariant("success");
            setTooltipContent("Login succeeded");
            tooltip.onOpen();
            handleClose();
        } catch (err) {
            setError(err.info?.message || "An unexpected error occurred.");
            setTooltipVariant("error");
            setTooltipContent(
                err.info?.message || `Login failed (${err.status || "unknown"})`
            );
            tooltip.onOpen();
        }
    };

    return (
        <React.Fragment>
            <Button
                variant='outlined'
                color='inherit'
                onClick={handleClickOpen}>
                {buttonText}
            </Button>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Login</DialogTitle>
                <DialogContent>
                    <DialogContentText sx={{ mb: 2 }}>
                        To access your account, please enter your username and
                        password.
                    </DialogContentText>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <TextField
                            autoFocus
                            margin='dense'
                            label='Username'
                            type='text'
                            fullWidth
                            variant='standard'
                            {...register("username", {
                                required: "Username is required",
                            })}
                            disabled={isLoggingIn}
                            error={!!errors.username}
                            helperText={errors.username?.message}
                        />
                        <TextField
                            margin='dense'
                            label='Password'
                            type='password'
                            fullWidth
                            variant='standard'
                            {...register("password", {
                                required: "Password is required",
                            })}
                            disabled={isLoggingIn}
                            error={!!errors.password}
                            helperText={errors.password?.message}
                        />
                        {error && (
                            <Typography color='error' sx={{ mt: 2 }}>
                                {error}
                            </Typography>
                        )}
                        <DialogActions sx={{ px: 0 }}>
                            <Button
                                onClick={handleClose}
                                disabled={isLoggingIn}>
                                Cancel
                            </Button>
                            <ModernTooltip
                                title={tooltipContent}
                                variant={tooltipVariant}
                                open={tooltip.open}
                                onClose={tooltip.onClose}>
                                <Button type='submit' disabled={isLoggingIn}>
                                    {isLoggingIn ? (
                                        <CircularProgress size={24} />
                                    ) : (
                                        "Login"
                                    )}
                                </Button>
                            </ModernTooltip>
                        </DialogActions>
                    </form>
                </DialogContent>
            </Dialog>
        </React.Fragment>
    );
}
