/** @format */

"use client";

import RegisterFullModal from "./RegisterFullModal";

export default function RegisterForm() {
    return <RegisterFullModal buttonText='Register' />;
}
