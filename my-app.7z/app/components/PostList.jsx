/** @format */

"use client";

import { useInfinitePosts } from "../lib/hooks/usePosts";
import PostCard from "./Post/PostCard";
import Stack from "@mui/material/Stack";
import { CircularProgress, Box, Typography } from "@mui/material";
import InfiniteScroll from "react-infinite-scroll-component";
import PostListSkeleton from "./Skeletons/PostListSkeleton";
// import removed: lightTheme from "../../lib/theme";
import { useThemeMode } from "../../lib/ThemeContext";
import PostSkeleton from "./Skeletons/PostSkeleton";
import NewPostModalWithFeedUpdate from "./NewPostModalWithFeedUpdate";
import { useUser } from "../lib/hooks/useAuth";
import { v4 as uuidv4 } from "uuid";
export default function InfinitePostsAuto() {
    const {
        posts,
        isLoading,
        isLoadingMore,
        isReachedEnd,
        size,
        setSize,
        mutate,
    } = useInfinitePosts();
    const { theme } = useThemeMode();
    const { user } = useUser();

    if (isLoading) {
        return <PostListSkeleton />;
    }

    return (
        <>
            {user && (
                <Box mb={3} display='flex' justifyContent='flex-end'>
                    <NewPostModalWithFeedUpdate />
                </Box>
            )}
            <InfiniteScroll
                dataLength={posts.length}
                next={() => setSize(size + 1)}
                hasMore={!isReachedEnd}
                loader={<PostSkeleton />}
                endMessage={
                    <Typography align='center' my={3}>
                        🎉 You have seen it all!
                    </Typography>
                }
                scrollThreshold={0.9}>
                <Stack spacing={4}>
                    {posts.map((post) => (
                        <div
                            key={uuidv4()}
                            style={{
                                marginBottom: theme.spacing(3),
                                animation:
                                    "fadeIn 0.6s cubic-bezier(0.4,0,0.2,1)",
                            }}>
                            <PostCard post={post} mutatePosts={mutate} />
                        </div>
                    ))}
                </Stack>
            </InfiniteScroll>
        </>
    );
}
