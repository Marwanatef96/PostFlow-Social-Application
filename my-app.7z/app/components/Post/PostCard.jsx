/** @format */

"use client";
import * as React from "react";
// import removed: theme from "../../../lib/theme";
import { useThemeMode } from "../../../lib/ThemeContext";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Collapse from "@mui/material/Collapse";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import CommentIcon from "@mui/icons-material/Comment";
import CommentSection from "./CommentSection";
import { useState } from "react";

import { useUser } from "../../lib/hooks/useAuth";
import dynamic from "next/dynamic";
import Link from "next/link";
import DeletePostButton from "../DeletePostButton";

const UpdatePostModalWithData = dynamic(
    () => import("../UpdatePostModalWithData"),
    { ssr: false }
);

function PostCard({ post, mutatePosts }) {
    const toSrc = (value) =>
        typeof value === "string" ? value : value?.url ? value.url : "";
    const IMAGE_PLACEHOLDER =
        "https://placehold.co/600x300/1e1e1e/FFFFFF?text=Image+Not+Found";
    const [showComments, setShowComments] = useState(false);
    const [loadingNext, setLoadingNext] = useState(false);
    const { user } = useUser();
    const { theme } = useThemeMode();
    const isOwner =
        user &&
        post.author &&
        (user.id === post.author.id || user._id === post.author.id);

    return (
        <>
            {loadingNext ? (
                <Card sx={{ maxWidth: "100%", mb: 2 }}>
                    {/* Use PostSkeleton for loading next batch */}
                    <CardContent sx={{ p: 0 }}>
                        <PostSkeleton />
                    </CardContent>
                </Card>
            ) : null}
            <Card
                sx={{
                    maxWidth: "100%",
                    background: "var(--color-surface)",
                    borderRadius: "var(--border-radius)",
                    boxShadow: "0 2px 8px rgba(60,60,60,0.06)",
                    border: "1px solid var(--color-border)",
                    transition: "var(--transition)",
                    "&:hover": {
                        boxShadow: 6,
                        borderColor: "var(--color-primary)",
                    },
                }}>
                <CardHeader
                    avatar={
                        <Link
                            href={`/profile/${post.author.id}`}
                            style={{
                                textDecoration: "none",
                                color: "inherit",
                            }}>
                            <Avatar
                                src={toSrc(post.author.profile_image)}
                                aria-label='recipe'>
                                {post.author.name.charAt(0)}
                            </Avatar>{" "}
                        </Link>
                    }
                    action={
                        isOwner && (
                            <div style={{ display: "flex", gap: 8 }}>
                                <UpdatePostModalWithData post={post} />
                                <DeletePostButton
                                    postId={post.id}
                                    mutatePosts={mutatePosts}
                                />
                            </div>
                        )
                    }
                    title={
                        <span style={{ color: "var(--color-primary)" }}>
                            {post.author.name}
                        </span>
                    }
                    subheader={post.created_at}
                    sx={{ cursor: "pointer" }}
                />{" "}
                <CardMedia
                    component='img'
                    height='300'
                    image={toSrc(post.image) || IMAGE_PLACEHOLDER}
                    alt={post.title}
                    onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = IMAGE_PLACEHOLDER;
                    }}
                />
                <CardContent>
                    <Typography
                        variant='h5'
                        component='div'
                        gutterBottom
                        sx={{ color: "var(--color-primary)", fontWeight: 700 }}>
                        {post.title}
                    </Typography>
                    <Typography
                        variant='body2'
                        color='text.secondary'
                        sx={{
                            color: "var(--color-text)",
                            fontSize: "1rem",
                            mb: 2,
                        }}>
                        {post.body}
                    </Typography>
                </CardContent>
                <CardActions
                    disableSpacing
                    sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <IconButton
                        aria-label='show comments'
                        onClick={() => setShowComments((prev) => !prev)}
                        sx={{
                            color: "var(--color-primary)",
                            transition: "var(--transition)",
                        }}>
                        <CommentIcon />
                    </IconButton>
                    <Typography
                        variant='body2'
                        color='text.secondary'
                        sx={{ color: "var(--color-muted)" }}>
                        {post?.comments_count}
                    </Typography>
                </CardActions>
                <Collapse in={showComments} timeout='auto' unmountOnExit>
                    <CardContent
                        sx={{
                            background: "var(--color-background)",
                            borderRadius: "var(--border-radius)",
                            p: 0,
                        }}>
                        <CommentSection postId={post.id} />
                    </CardContent>
                </Collapse>
            </Card>
        </>
    );
}

export default PostCard;
