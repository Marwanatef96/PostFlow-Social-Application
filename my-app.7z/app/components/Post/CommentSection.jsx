/** @format */

"use client";

import * as React from "react";
// import removed: lightTheme from "../../../lib/theme";
import { useThemeMode } from "../../../lib/ThemeContext";
import Box from "@mui/material/Box";
import CommentSkeleton from "../Skeletons/CommentSkeleton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import Avatar from "@mui/material/Avatar";
import ListItemText from "@mui/material/ListItemText";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useState } from "react";
import { useCreateComment, useComments } from "../../lib/hooks/useComments";
import { usePost } from "../../lib/hooks/usePosts";
import { useAuth, getToken } from "../../lib/hooks/useAuth";
import { mutate } from "swr";
import Cookies from "js-cookie";
import ModernTooltip, { useTooltipState } from "../ModernTooltip/ModernTooltip";

function CommentSection({ postId }) {
    const toSrc = (value) =>
        typeof value === "string" ? value : value?.url ? value.url : "";
    const { theme } = useThemeMode();
    const { user } = useAuth();
    const { post, postError, isPostLoading } = usePost(postId);
    const { createComment, isCreating } = useCreateComment(postId);
    const [newComment, setNewComment] = useState("");
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const tooltip = useTooltipState(false);
    const [tooltipContent, setTooltipContent] = useState("");
    const [tooltipVariant, setTooltipVariant] = useState("success");

    // Handle comment input change
    const handleNewCommentChange = (e) => {
        setNewComment(e.target.value);
    };

    // Handle comment submit
    const handleSubmit = async () => {
        if (!newComment.trim()) return;
        setIsLoading(true);
        setError(null);
        try {
            const token = getToken();
            await createComment({ commentBody: newComment, token });
            setNewComment("");
            mutate(`/api/posts/${postId}`); // Refresh post data
            setTooltipVariant("success");
            setTooltipContent("Comment posted");
            tooltip.onOpen();
        } catch (err) {
            setError("Failed to post comment.");
            setTooltipVariant("error");
            setTooltipContent(
                err.info?.message ||
                    `Comment failed (${err.status || "unknown"})`
            );
            tooltip.onOpen();
        } finally {
            setIsLoading(false);
        }
    };

    if (isPostLoading) {
        return (
            <Box sx={{ p: 2 }}>
                <List>
                    {[...Array(3)].map((_, i) => (
                        <CommentSkeleton key={i} />
                    ))}
                </List>
            </Box>
        );
    }
    if (postError) {
        return (
            <Box sx={{ p: 2 }}>
                <Typography sx={{ color: "error.main" }}>
                    Error loading comments.
                </Typography>
            </Box>
        );
    }

    return (
        <Box>
            <Divider />
            {post?.comments?.length === 0 ? (
                <Typography sx={{ p: 2, color: "text.secondary" }}>
                    No comments yet.
                </Typography>
            ) : (
                <List sx={{ width: "100%", bgcolor: "background.paper" }}>
                    {post?.comments?.map((comment, index) => (
                        <React.Fragment key={comment.id}>
                            <ListItem alignItems='flex-start'>
                                <ListItemAvatar>
                                    <Avatar
                                        alt={comment.author.username}
                                        src={toSrc(
                                            comment.author.profile_image
                                        )}
                                    />
                                </ListItemAvatar>
                                <ListItemText
                                    primary={comment.author.username}
                                    secondary={
                                        <>
                                            <Typography
                                                sx={{ display: "inline" }}
                                                component='span'
                                                variant='body2'
                                                color='text.primary'>
                                                {comment.body}
                                            </Typography>
                                        </>
                                    }
                                />
                            </ListItem>
                            {index < post?.comments.length - 1 && (
                                <Divider variant='inset' component='li' />
                            )}
                        </React.Fragment>
                    ))}
                </List>
            )}
            <Divider />
            {user && (
                <Box sx={{ p: 2, display: "flex" }}>
                    <TextField
                        value={newComment}
                        onChange={handleNewCommentChange}
                        fullWidth
                        variant='outlined'
                        label='Add a comment...'
                        disabled={isLoading || isCreating}
                    />
                    <ModernTooltip
                        title={tooltipContent}
                        variant={tooltipVariant}
                        open={tooltip.open}
                        onClose={tooltip.onClose}>
                        <Button
                            onClick={handleSubmit}
                            disabled={
                                isLoading || isCreating || !newComment.trim()
                            }
                            variant='contained'
                            sx={{ ml: 1 }}>
                            {isLoading || isCreating ? "Posting..." : "Post"}
                        </Button>
                    </ModernTooltip>
                </Box>
            )}
            {error && (
                <Typography sx={{ color: "error.main", p: 2 }}>
                    {error}
                </Typography>
            )}
        </Box>
    );
}

export default CommentSection;
