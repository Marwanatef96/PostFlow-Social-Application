/** @format */

import React from "react";
import { useCreatePost } from "../lib/hooks/usePosts";
import NewPostModal from "./Post/NewPostModal";
import { useInfinitePosts } from "../lib/hooks/usePosts";
import ModernTooltip, { useTooltipState } from "./ModernTooltip/ModernTooltip";

export default function NewPostModalWithFeedUpdate() {
    const { mutate } = useInfinitePosts();
    const { createPost, isCreating } = useCreatePost();
    const tooltip = useTooltipState(false);
    const [tooltipContent, setTooltipContent] = React.useState("");
    const [tooltipVariant, setTooltipVariant] = React.useState("success");

    const handleNewPost = async (data) => {
        try {
            await createPost({ postData: data });
            mutate();
            setTooltipVariant("success");
            setTooltipContent("Post created successfully");
            tooltip.onOpen();
        } catch (err) {
            setTooltipVariant("error");
            setTooltipContent(
                err.info?.message ||
                    `Post creation failed (${err.status || "unknown"})`
            );
            tooltip.onOpen();
        }
    };

    return (
        <ModernTooltip
            title={tooltipContent}
            variant={tooltipVariant}
            open={tooltip.open}
            onClose={tooltip.onClose}>
            <NewPostModal onSubmit={handleNewPost} />
        </ModernTooltip>
    );
}
