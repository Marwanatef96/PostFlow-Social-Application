/** @format */
"use client";

import * as React from "react";
// import removed: theme from "../../../lib/theme";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import ForumIcon from "@mui/icons-material/Forum";
import Link from "next/link";
import { useAuth, getToken } from "../../lib/hooks/useAuth";
import { useThemeMode } from "../../../lib/ThemeContext"; // Updated import
import LoginModal from "../Auth/LoginModal";
import RegisterForm from "../Auth/RegisterForm";
import ThemeToggleButton from "./ThemeToggleButton";
import ModernTooltip, { useTooltipState } from "../ModernTooltip/ModernTooltip";
function Navbar() {
    const { user, logout } = useAuth();
    const logoutTip = useTooltipState(false);
    const [logoutMessage, setLogoutMessage] = React.useState("");
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => setMounted(true), []);
    const [anchorElNav, setAnchorElNav] = React.useState(null);
    const handleOpenNavMenu = (event) => setAnchorElNav(event.currentTarget);
    const handleCloseNavMenu = () => setAnchorElNav(null);
    const navPages = user
        ? [
              { name: "Home", path: "/" },
              { name: "Profile", path: `/profile/${user?.id}` },
          ]
        : [{ name: "Home", path: "/" }];

    if (!mounted) {
        return (
            <AppBar
                position='fixed'
                sx={{
                    background: "var(--color-navbar)",
                    borderBottom: "1px solid var(--color-border)",
                    boxShadow: "0 2px 8px rgba(60,60,60,0.04)",
                    transition: "var(--transition)",
                }}>
                <Container maxWidth='xl'>
                    <Toolbar disableGutters sx={{ minHeight: "64px" }}>
                        <ForumIcon
                            sx={{
                                display: { xs: "none", md: "flex" },
                                mr: 1,
                                color: "var(--color-primary)",
                            }}
                        />
                        <Typography
                            variant='h6'
                            noWrap
                            component={Link}
                            href='/'
                            sx={{
                                mr: 2,
                                display: { xs: "none", md: "flex" },
                                fontFamily: "monospace",
                                fontWeight: 700,
                                letterSpacing: ".3rem",
                                color: "var(--color-primary)",
                                textDecoration: "none",
                            }}>
                            PostFlow
                        </Typography>
                    </Toolbar>
                </Container>
            </AppBar>
        );
    }

    const toSrc = (value) =>
        typeof value === "string" ? value : value?.url ? value.url : "";

    return (
        <AppBar
            position='fixed'
            sx={{
                background: "var(--color-navbar)",
                borderBottom: "1px solid var(--color-border)",
                boxShadow: "0 2px 8px rgba(60,60,60,0.04)",
                transition: "var(--transition)",
            }}>
            <Container maxWidth='xl'>
                <Toolbar
                    disableGutters
                    sx={{ minHeight: "64px", transition: "var(--transition)" }}>
                    <ForumIcon
                        sx={{
                            display: { xs: "none", md: "flex" },
                            mr: 1,
                            color: "var(--color-primary)",
                        }}
                    />
                    <Typography
                        variant='h6'
                        noWrap
                        component={Link}
                        href='/'
                        sx={{
                            mr: 2,
                            display: { xs: "none", md: "flex" },
                            fontFamily: "monospace",
                            fontWeight: 700,
                            letterSpacing: ".3rem",
                            color: "var(--color-primary)",
                            textDecoration: "none",
                            transition: "var(--transition)",
                        }}>
                        PostFlow
                    </Typography>
                    <Box sx={{ ml: 2 }}>
                        <ThemeToggleButton />
                    </Box>
                    {/* Mobile Menu */}
                    <Box
                        sx={{
                            flexGrow: 1,
                            display: { xs: "flex", md: "none" },
                        }}>
                        <IconButton
                            size='large'
                            aria-label='menu'
                            aria-controls='menu-appbar'
                            aria-haspopup='true'
                            onClick={handleOpenNavMenu}
                            color='inherit'>
                            <MenuIcon />
                        </IconButton>
                        <Menu
                            id='menu-appbar'
                            anchorEl={anchorElNav}
                            anchorOrigin={{
                                vertical: "bottom",
                                horizontal: "left",
                            }}
                            keepMounted
                            transformOrigin={{
                                vertical: "top",
                                horizontal: "left",
                            }}
                            open={Boolean(anchorElNav)}
                            onClose={handleCloseNavMenu}
                            sx={{ display: { xs: "block", md: "none" } }}>
                            {navPages.map((page) => (
                                <MenuItem
                                    key={page.name}
                                    onClick={handleCloseNavMenu}
                                    component={Link}
                                    href={page.path}>
                                    <Typography textAlign='center'>
                                        {page.name}
                                    </Typography>
                                </MenuItem>
                            ))}
                        </Menu>
                    </Box>
                    {/* Desktop menu */}
                    <Box
                        sx={{
                            flexGrow: 1,
                            display: { xs: "none", md: "flex" },
                            justifyContent: "center",
                        }}>
                        {navPages.map((page) => (
                            <Button
                                key={page.name}
                                component={Link}
                                href={page.path}
                                sx={{
                                    my: 2,
                                    color: "var(--color-primary)",
                                    fontWeight: 500,
                                    borderRadius: "var(--border-radius)",
                                    transition: "var(--transition)",
                                    "&:hover": {
                                        background: "var(--color-primary)",
                                        color: "#fff",
                                    },
                                }}>
                                {page.name}
                            </Button>
                        ))}
                    </Box>
                    {/* Right Section */}
                    <Box
                        sx={{
                            flexGrow: 0,
                            display: "flex",
                            alignItems: "center",
                        }}>
                        {user ? (
                            <>
                                <Box
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        mr: 2,
                                    }}>
                                    <Avatar
                                        alt={user.name || user.username}
                                        src={toSrc(user.profile_image)}
                                        sx={{ mr: 1 }}
                                    />
                                    <Typography
                                        sx={{
                                            mr: 1,
                                            fontWeight: 500,
                                            color: "var(--color-text)",
                                            fontSize: {
                                                xs: "1rem",
                                                md: "1.1rem",
                                            },
                                        }}>
                                        {user.name || user.username}
                                    </Typography>
                                </Box>
                                <ModernTooltip
                                    title={logoutMessage}
                                    variant='info'
                                    open={logoutTip.open}
                                    onClose={logoutTip.onClose}>
                                    <Button
                                        variant='outlined'
                                        color='inherit'
                                        onClick={() => {
                                            logout();
                                            setLogoutMessage("Logged out");
                                            logoutTip.onOpen();
                                        }}
                                        sx={{
                                            borderColor: "var(--color-primary)",
                                            color: "var(--color-primary)",
                                            borderRadius:
                                                "var(--border-radius)",
                                            transition: "var(--transition)",
                                            "&:hover": {
                                                background:
                                                    "var(--color-primary)",
                                                color: "#fff",
                                            },
                                        }}>
                                        Logout
                                    </Button>
                                </ModernTooltip>
                            </>
                        ) : (
                            <Box
                                sx={{
                                    display: "flex",
                                    gap: 1,
                                    alignItems: "center",
                                }}>
                                <LoginModal buttonText='Login' />
                                <RegisterForm />
                            </Box>
                        )}
                    </Box>
                </Toolbar>
            </Container>
        </AppBar>
    );
}

export default Navbar;
