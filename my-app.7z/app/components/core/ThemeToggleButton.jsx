/** @format */

import React from "react";
import { useThemeMode } from "../../../lib/ThemeContext";
import IconButton from "@mui/material/IconButton";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeIcon from "@mui/icons-material/DarkMode";

export default function ThemeToggleButton() {
    const { theme, toggleTheme } = useThemeMode();
    const isDark = theme.palette.mode === "dark";
    return (
        <IconButton
            onClick={toggleTheme}
            color='inherit'
            aria-label='Toggle theme'>
            {isDark ? <LightModeIcon /> : <DarkModeIcon />}
        </IconButton>
    );
}
