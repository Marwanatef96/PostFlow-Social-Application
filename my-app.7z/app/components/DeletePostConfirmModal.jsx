/** @format */

import * as React from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";

export default function DeletePostConfirmModal({
    open,
    onClose,
    onConfirm,
    loading,
}) {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Delete Post</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Are you sure you want to delete this post? This action
                    cannot be undone.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button
                    onClick={onClose}
                    color='primary'
                    variant='outlined'
                    disabled={loading}>
                    Cancel
                </Button>
                <Button
                    onClick={onConfirm}
                    color='error'
                    variant='contained'
                    disabled={loading}>
                    {loading ? "Deleting..." : "Delete"}
                </Button>
            </DialogActions>
        </Dialog>
    );
}
