/** @format */

import React, { useState } from "react";
import NewPostModal from "./Post/NewPostModal";
import { useUpdatePost, useInfinitePosts } from "../lib/hooks/usePosts";
import ModernTooltip, { useTooltipState } from "./ModernTooltip/ModernTooltip";
import Button from "@mui/material/Button";
export default function UpdatePostModalWithData({ post, onUpdated }) {
    const [open, setOpen] = useState(false);
    const { updatePost, isUpdating } = useUpdatePost(post.id);
    const { mutate } = useInfinitePosts();
    const tooltip = useTooltipState(false);
    const [tooltipContent, setTooltipContent] = useState("");
    const [tooltipVariant, setTooltipVariant] = useState("success");

    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const handleUpdate = async (data) => {
        try {
            await updatePost({ postData: data });
            setOpen(false);
            mutate();
            if (onUpdated) onUpdated();
            setTooltipVariant("success");
            setTooltipContent("Post updated successfully");
            tooltip.onOpen();
        } catch (err) {
            setTooltipVariant("error");
            setTooltipContent(
                err.info?.message ||
                    `Update failed (${err.status || "unknown"})`
            );
            tooltip.onOpen();
        }
    };

    return (
        <>
            <ModernTooltip
                title={tooltipContent}
                variant={tooltipVariant}
                open={tooltip.open}
                onClose={tooltip.onClose}>
                <Button variant='outlined' onClick={handleOpen} size='small'>
                    Update
                </Button>
            </ModernTooltip>
            {open && (
                <NewPostModal
                    onSubmit={handleUpdate}
                    initialData={{
                        title: post.title,
                        body: post.body,
                        image: post.image,
                    }}
                    openOverride={open}
                    onCloseOverride={handleClose}
                    isUpdating={isUpdating}
                />
            )}
        </>
    );
}
