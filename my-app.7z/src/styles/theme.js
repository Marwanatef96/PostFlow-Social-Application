/** @format */

import { createTheme } from "@mui/material/styles";

export const baseThemeOptions = {
    shape: { borderRadius: 12 },
    typography: {
        fontFamily: "Inter, 'Segoe UI', Arial, sans-serif",
        h1: { fontSize: "2.5rem", fontWeight: 600 },
        h2: { fontSize: "2.25rem", fontWeight: 600 },
        h3: { fontSize: "2rem", fontWeight: 600 },
        h4: { fontSize: "1.75rem", fontWeight: 600 },
        h5: { fontSize: "1.5rem", fontWeight: 600 },
        h6: { fontSize: "1.25rem", fontWeight: 600 },
    },
    spacing: 8,
};

export const lightTheme = createTheme({
    ...baseThemeOptions,
    palette: {
        mode: "light",
        primary: { main: "#673ab7" },
        secondary: { main: "#f50057" },
        background: { default: "#fafafa", paper: "#ffffff" },
        divider: "#e0e0e0",
    },
});

export const darkTheme = createTheme({
    ...baseThemeOptions,
    palette: {
        mode: "dark",
        primary: { main: "#90caf9" },
        secondary: { main: "#ffb86b" },
        background: { default: "#121212", paper: "#1e1e1e" },
        divider: "#333",
    },
});
